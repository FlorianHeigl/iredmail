<?php
/**
 * IMAP ACL
 *
 * Sample plugin to show/modify IMAP ACLs
 *
 * @version 0.1
 * @author Holger Mauermann
 */

class imap_acl extends rcube_plugin
{
    public  $task    = 'settings';    
    
    function init()
    {
        $this->add_hook('folder_form', array($this, 'folder_form'));
        $this->add_hook('folder_update', array($this, 'folder_update'));
        $this->add_texts('localization/', true);
        $this->include_script('imap_acl.js');
    }


    function folder_form($args)
    {
        // edited folder name (empty in create-folder mode)
        $mbox = trim(get_input_value('_mbox', RCUBE_INPUT_GPC, true));
        if (empty($mbox)) return $args;
        $mbox_imap = rcube_charset_convert($mbox, RCMAIL_CHARSET, 'UTF7-IMAP');
        
        $rcmail = rcmail::get_instance();

        // do nothing if no ACL support
        if (!$rcmail->imap->get_capability('ACL')) return $args;

        $form = $args['form'];

        // get folder type
        $foldertype = 'privatefolder';
        $namespace = $rcmail->imap->get_namespace();

        foreach ((array)$namespace['other'] as $ns) {
            if ($ns[0] && strpos($mbox_imap, $ns[0]) === 0) {
                $foldertype = 'otherfolder';
            }
        }
        
        foreach ((array)$namespace['shared'] as $ns) {
            if ($ns[0] && strpos($mbox_imap, $ns[0]) === 0) {
                $foldertype = 'publicfolder';
            }
        }
        
        // add foldertype to 'info' fieldset
        $form['props']['fieldsets']['info']['content']['foldertype'] = array(
                'label' => Q($this->gettext('foldertype')),
                'value' => Q($this->gettext($foldertype)));
        
        $myrights = $rcmail->imap->my_rights($mbox_imap);

        // add myrights to 'info' fieldset
        $form['props']['fieldsets']['info']['content']['myrights'] = array(
                'label' => Q($this->gettext('myrights')),
                'value' => $this->acl2text($myrights));

        // return if not folder admin
        $args['form'] = array_merge($args['form'], $form);
        if (!is_array($myrights) || !in_array('a', $myrights)) return $args;

        // get ACL for folder
        $getacl = $rcmail->imap->get_acl($mbox_imap);

        // add info if folder is shared to others
        if (count($getacl) > 1) {
            $form['props']['fieldsets']['info']['content']['foldertype']['value'] .=
                    sprintf(', ' . Q($this->gettext('sharedto')), count($getacl) - 1);
        }

        // the 'sharing' fieldset
        $form['sharing']['name'] = Q($this->gettext('sharing'));
        $form['sharing']['fieldsets']['shares']['name'] = Q($this->gettext('shares'));

        uksort($getacl, 'strnatcasecmp');
        $i = 1;
        foreach ($getacl as $user => $rights) {
            if ($rcmail->imap->conn->user == $user) {
                continue;
            }
            $form['sharing']['fieldsets']['shares']['content'][$user] = array(
                    'label' => $i,
                    'value' => $this->acl_form_html($i, $user, $rights));
            $i++;
        }

        $form['sharing']['fieldsets']['shares']['content']['acl_add'] = array(
                'label' => Q($this->gettext('acl_add')),
                'value' => $this->acl_form_html());

        // show some help
        $table = new html_table(array('cols' => 8, 'id' => '_acl_help'));

        foreach ($this->rights_supported() as $right) {
            $table->add('title', $right . ':');
            $table->add(null, Q($this->gettext('acl_' . $right)));
        }
        $form['sharing']['fieldsets']['help']['name'] = Q($this->gettext('help'));
        $form['sharing']['fieldsets']['help']['content'] = $table->show();

        $args['form'] = array_merge($args['form'], $form);
        return $args;
    }

    function folder_update($args)
    {
        $rcmail = rcmail::get_instance();

        // do nothing if no ACL support
        if (!$rcmail->imap->get_capability('ACL')) return $args;

        // use oldname, plugin runs before main folder_update
        $mbox_imap = $args['record']['oldname'];

        $oldacl = $rcmail->imap->get_acl($mbox_imap);
        unset($oldacl[$rcmail->imap->conn->user]);

        $post = get_input_value('_acl', RCUBE_INPUT_POST);

        $setacl = array();

        foreach ((array)$post as $acl) {

            $user = trim($acl['user']);
            $rights = strtolower(trim($acl['acl']));
            $custom = strtolower(trim($acl['cust']));

            if ($rights == 'custom') $rights = $custom;

            if (!empty($user) && !empty($rights)) {

                // filter out unsupported rights
                $rights = array_intersect(str_split($rights), $this->rights_supported());

                if (!array_key_exists($user, $oldacl)
                        || !$this->acl_compare($rights, $oldacl[$user])) {
                    // new user or changed rights
                    $setacl[$user] = $rights;
                }
                unset($oldacl[$user]);
            }
        }

        foreach ($setacl as $user => $rights) {
            if (!$rcmail->imap->set_acl($mbox_imap, $user, $rights)) {
                $args['abort'] = true;
                break;
            }
        }

        foreach ($oldacl as $user => $rights) {
            if (!$rcmail->imap->delete_acl($mbox_imap, $user)) {
                $args['abort'] = true;
                break;
            }
        }
        
        if ($args['abort']) {
            $args['result'] = false;
        }

        return $args;
    }

    
    function acl_form_html($num = 0, $user = '', $rights = array())
    {
        $fullrights = $this->rights_supported();

        // filter out virtual rights (c or d) the server may return
        $userrights = implode(array_intersect($rights, $fullrights));

        // depending on server capability either use 'te' or 'd' for deleting msgs
        $deleteright = implode(array_intersect(str_split('ted'), $fullrights));

        $html = '';

        // User input
        $input = new html_inputfield(array(
                'name' => '_acl['.$num.'][user]',
                'id' => '_acl_'.$num.'_user',
                'size' => 25));
        
        $html .= sprintf(' <label for="_acl_%d_user">%s</label> %s ',
                $num, Q($this->gettext('user')), $input->show($user));

        // default rights for new shares
        if (empty($userrights)) $userrights = 'lrs';

        // select field
        $select = new html_select(array(
                'name' => '_acl['.$num.'][acl]',
                'id' => '_acl_'.$num.'_acl'));

        // with some predefined rights
        $items = array(
            'read' => 'lrs',
            'write' => 'lrswi',
            'delete' => 'lrswi' . $deleteright,
            'full' => implode($fullrights),
            'custom' => 'custom',
            'revoke' => '');

        $selected = false;

        foreach ($items as $title => $right) {
            $select->add(Q($this->gettext('acl_' . $title)), $right);
            if ($this->acl_compare($userrights, $right)) {
                $selected = $right;
            }
        }
        if (!$selected) $selected = 'custom';

        $html .= sprintf(' <label for="_acl_%d_acl">%s</label> %s ',
                $num, Q($this->gettext('rights')), $select->show($selected));

        // Custom rights
        $input = new html_inputfield(array(
                'name' => '_acl['.$num.'][cust]',
                'id' => '_acl_'.$num.'_cust',
                'size' => 12));

        $html .= $input->show($userrights);

        return $html;
    }
    
        
    function acl2text($rights)
    {
        if (empty($rights)) return '';

        $text = array();
        $all = $this->rights_supported();

        foreach ($all as $right) {

            if (in_array($right, $rights)) {
                $text[] = Q($this->gettext('acl_' . $right));
            }
        }

        if (count($text) == count($all))
                return Q($this->gettext('acl_full'));

        return implode(', ', $text);
    }


    function acl_compare($acl1, $acl2)
    {
        if (!is_array($acl1)) $acl1 = str_split($acl1);
        if (!is_array($acl2)) $acl2 = str_split($acl2);

        $rights = $this->rights_supported();
        $acl1 = array_intersect($acl1, $rights);
        $acl2 = array_intersect($acl2, $rights);

        sort($acl1);
        sort($acl2);
        
        if ($acl1 == $acl2) return true;
        return false;
    }

    function rights_supported()
    {
        $rcmail = rcmail::get_instance();

        $capa = $rcmail->imap->get_capability('RIGHTS');

        if (is_array($capa)) {
            $rights = strtolower($capa[0]);
        }
        else {
            $rights = 'cd';
        }

        return str_split('lrswi' . $rights . 'pa');
    }
}
