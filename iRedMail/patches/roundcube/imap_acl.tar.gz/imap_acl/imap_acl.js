/*
 * IMAP ACL plugin script
 *
 * @version 0.1
 * @author Holger Mauermann
 */

if (window.rcmail) {
    rcmail.addEventListener('init', function() {

        var allSelects = $('select[name^="_acl"]');
        var allCustomInputs = $('input[name$="cust\\]"]');
        var helpFieldset = $('table#_acl_help').parents('fieldset:first');

        helpFieldset.hide();

        allCustomInputs.each(function() {
            $(this).hide()
        });
        
        allSelects.each(function() {

            var customInput = $(this).next('input');

            if ($(this).val() == 'custom') {
                customInput.show();
                helpFieldset.show();
            }

            $(this).change(function() {
                
                if ($(this).val() == 'custom') {
                    customInput.show();
                    helpFieldset.show();
                } else {
                    customInput.hide();
                }
            });
        });
    });
}